CREATE TABLE `siteSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`siteName` varchar(255) NOT NULL DEFAULT 'WOW Tasks',
	`siteDescription` text NOT NULL DEFAULT ('Earn Daily Rewards'),
	`primaryColor` varchar(7) NOT NULL DEFAULT '#f97316',
	`secondaryColor` varchar(7) NOT NULL DEFAULT '#ec4899',
	`accentColor` varchar(7) NOT NULL DEFAULT '#06b6d4',
	`backgroundColor` varchar(7) NOT NULL DEFAULT '#0f172a',
	`headerText` varchar(255) NOT NULL DEFAULT 'مرحباً بك في WOW Tasks',
	`headerSubtext` text NOT NULL DEFAULT ('ابدأ كسب الأموال اليوم من خلال إكمال المهام البسيطة'),
	`minWithdrawal` decimal(10,2) NOT NULL DEFAULT '10',
	`maxWithdrawal` decimal(10,2) NOT NULL DEFAULT '10000',
	`telegramLink` varchar(255) NOT NULL DEFAULT 'https://t.me/yourgroupname',
	`supportEmail` varchar(255) NOT NULL DEFAULT 'support@example.com',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `siteSettings_id` PRIMARY KEY(`id`)
);
