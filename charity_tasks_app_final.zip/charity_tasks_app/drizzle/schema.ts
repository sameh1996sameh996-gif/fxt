import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  longtext,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with subscription and wallet fields.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  
  // Subscription fields
  isSubscribed: boolean("isSubscribed").default(false).notNull(),
  subscriptionExpiresAt: timestamp("subscriptionExpiresAt"),
  
  // Wallet fields
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0").notNull(),
  totalEarned: decimal("totalEarned", { precision: 12, scale: 2 }).default("0").notNull(),
  totalWithdrawn: decimal("totalWithdrawn", { precision: 12, scale: 2 }).default("0").notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tasks table - stores daily tasks created by admin
 */
export const tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: longtext("description"),
  reward: decimal("reward", { precision: 10, scale: 2 }).notNull(),
  dailyLimit: int("dailyLimit").default(1).notNull(), // How many times per day
  isActive: boolean("isActive").default(true).notNull(),
  requiresProof: boolean("requiresProof").default(true).notNull(), // Does it need screenshot/text proof?
  proofType: mysqlEnum("proofType", ["text", "image", "both"]).default("both"),
  
  createdBy: int("createdBy").notNull(), // Admin who created it
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = typeof tasks.$inferInsert;

/**
 * Task submissions - tracks when users complete tasks
 */
export const taskSubmissions = mysqlTable("taskSubmissions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  taskId: int("taskId").notNull(),
  
  // Proof fields
  proofText: longtext("proofText"),
  proofImageUrl: varchar("proofImageUrl", { length: 500 }),
  
  // Status tracking
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  submittedAt: timestamp("submittedAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
  reviewedBy: int("reviewedBy"), // Admin who reviewed it
  
  rejectionReason: text("rejectionReason"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TaskSubmission = typeof taskSubmissions.$inferSelect;
export type InsertTaskSubmission = typeof taskSubmissions.$inferInsert;

/**
 * Transactions - tracks all wallet movements
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  
  type: mysqlEnum("type", ["task_reward", "withdrawal", "refund"]).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  
  // Reference to related record
  taskSubmissionId: int("taskSubmissionId"),
  withdrawalId: int("withdrawalId"),
  
  balanceBefore: decimal("balanceBefore", { precision: 12, scale: 2 }).notNull(),
  balanceAfter: decimal("balanceAfter", { precision: 12, scale: 2 }).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Withdrawals - tracks user withdrawal requests
 */
export const withdrawals = mysqlTable("withdrawals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "completed"]).default("pending").notNull(),
  
  // Payment details
  paymentMethod: mysqlEnum("paymentMethod", ["bank_transfer", "mobile_wallet", "crypto"]).notNull(),
  paymentDetails: longtext("paymentDetails").notNull(), // JSON with account info
  
  // Review tracking
  requestedAt: timestamp("requestedAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
  reviewedBy: int("reviewedBy"), // Admin who reviewed it
  
  rejectionReason: text("rejectionReason"),
  completedAt: timestamp("completedAt"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Withdrawal = typeof withdrawals.$inferSelect;
export type InsertWithdrawal = typeof withdrawals.$inferInsert;

/**
 * Subscriptions - tracks subscription plans and user subscriptions
 */
export const subscriptionPlans = mysqlTable("subscriptionPlans", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  durationDays: int("durationDays").notNull(), // How many days the subscription lasts
  isActive: boolean("isActive").default(true).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = typeof subscriptionPlans.$inferInsert;

/**
 * Subscription purchases - tracks when users buy subscriptions
 */
export const subscriptionPurchases = mysqlTable("subscriptionPurchases", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  planId: int("planId").notNull(),
  
  purchasedAt: timestamp("purchasedAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SubscriptionPurchase = typeof subscriptionPurchases.$inferSelect;
export type InsertSubscriptionPurchase = typeof subscriptionPurchases.$inferInsert;

/**
 * Notifications - tracks notifications sent to users and admin
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  type: mysqlEnum("type", ["task_approved", "task_rejected", "withdrawal_approved", "withdrawal_rejected", "system"]).notNull(),
  
  // Reference to related record
  taskSubmissionId: int("taskSubmissionId"),
  withdrawalId: int("withdrawalId"),
  
  isRead: boolean("isRead").default(false).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Site Settings - stores customization settings for the site
 */
export const siteSettings = mysqlTable("siteSettings", {
  id: int("id").autoincrement().primaryKey(),
  
  // General settings
  siteName: varchar("siteName", { length: 255 }).default("WOW Tasks").notNull(),
  siteDescription: text("siteDescription").default("Earn Daily Rewards").notNull(),
  
  // Colors
  primaryColor: varchar("primaryColor", { length: 7 }).default("#f97316").notNull(),
  secondaryColor: varchar("secondaryColor", { length: 7 }).default("#ec4899").notNull(),
  accentColor: varchar("accentColor", { length: 7 }).default("#06b6d4").notNull(),
  backgroundColor: varchar("backgroundColor", { length: 7 }).default("#0f172a").notNull(),
  
  // Header text
  headerText: varchar("headerText", { length: 255 }).default("مرحباً بك في WOW Tasks").notNull(),
  headerSubtext: text("headerSubtext").default("ابدأ كسب الأموال اليوم من خلال إكمال المهام البسيطة").notNull(),
  
  // Withdrawal settings
  minWithdrawal: decimal("minWithdrawal", { precision: 10, scale: 2 }).default("10").notNull(),
  maxWithdrawal: decimal("maxWithdrawal", { precision: 10, scale: 2 }).default("10000").notNull(),
  
  // Links
  telegramLink: varchar("telegramLink", { length: 255 }).default("https://t.me/yourgroupname").notNull(),
  supportEmail: varchar("supportEmail", { length: 255 }).default("support@example.com").notNull(),
  
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SiteSettings = typeof siteSettings.$inferSelect;
export type InsertSiteSettings = typeof siteSettings.$inferInsert;
