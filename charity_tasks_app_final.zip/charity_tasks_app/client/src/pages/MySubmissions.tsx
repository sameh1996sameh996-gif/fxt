import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, Loader2, CheckCircle, Clock, XCircle } from "lucide-react";

export default function MySubmissions() {
  const { user } = useAuth();
  const { data: submissions, isLoading } = trpc.tasks.getUserSubmissions.useQuery();

  const getStatusIcon = (status: string) => {
    if (status === 'approved') return <CheckCircle className="w-4 h-4 text-green-600" />;
    if (status === 'rejected') return <XCircle className="w-4 h-4 text-red-600" />;
    return <Clock className="w-4 h-4 text-yellow-600" />;
  };

  const getStatusLabel = (status: string) => {
    if (status === 'approved') return 'موافق عليها';
    if (status === 'rejected') return 'مرفوضة';
    return 'قيد المراجعة';
  };

  const getStatusColor = (status: string) => {
    if (status === 'approved') return 'bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-200';
    if (status === 'rejected') return 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-200';
    return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-200';
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="container py-6 flex items-center gap-4">
          <Link href="/tasks">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              العودة
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">إرسالاتي</h1>
        </div>
      </header>

      <main className="container py-12">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : !submissions || submissions.length === 0 ? (
          <Card className="card-premium">
            <CardHeader>
              <CardTitle>لا توجد إرسالات</CardTitle>
              <CardDescription>لم تقم بإرسال أي مهام حتى الآن</CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/tasks">
                <Button className="btn-primary">ابدأ بإنجاز المهام</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {submissions.map((submission: any) => (
              <Card key={submission.id} className="card-premium">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{submission.task?.title || 'مهمة'}</CardTitle>
                      <CardDescription className="mt-2">
                        تم الإرسال في: {new Date(submission.createdAt).toLocaleDateString('ar-SA')}
                      </CardDescription>
                    </div>
                    <Badge className={getStatusColor(submission.status)}>
                      <span className="flex items-center gap-1">
                        {getStatusIcon(submission.status)}
                        {getStatusLabel(submission.status)}
                      </span>
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {submission.proofText && (
                    <div>
                      <p className="text-sm font-semibold text-foreground mb-2">الدليل النصي:</p>
                      <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded">
                        {submission.proofText}
                      </p>
                    </div>
                  )}

                  {submission.proofImageUrl && (
                    <div>
                      <p className="text-sm font-semibold text-foreground mb-2">الصورة:</p>
                      <img
                        src={submission.proofImageUrl}
                        alt="proof"
                        className="max-w-xs rounded border border-border"
                      />
                    </div>
                  )}

                  {submission.status === 'rejected' && submission.rejectionReason && (
                    <div className="bg-red-50 dark:bg-red-950 border border-red-200 dark:border-red-800 rounded-lg p-4">
                      <p className="text-sm font-semibold text-red-800 dark:text-red-200 mb-1">سبب الرفض:</p>
                      <p className="text-sm text-red-700 dark:text-red-300">{submission.rejectionReason}</p>
                    </div>
                  )}

                  {submission.status === 'approved' && (
                    <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4">
                      <p className="text-sm font-semibold text-green-800 dark:text-green-200">
                        ✓ تمت الموافقة على مهمتك وتم إضافة الأرباح إلى رصيدك
                      </p>
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-4 border-t border-border">
                    <span className="text-sm text-muted-foreground">
                      المكافأة: <span className="font-semibold text-primary">{submission.task?.reward} ر.س</span>
                    </span>
                    {submission.reviewedAt && (
                      <span className="text-xs text-muted-foreground">
                        تمت المراجعة في: {new Date(submission.reviewedAt).toLocaleDateString('ar-SA')}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
