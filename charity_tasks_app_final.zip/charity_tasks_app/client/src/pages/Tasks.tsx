import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, Zap, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Tasks() {
  const { user } = useAuth();
  const [selectedTask, setSelectedTask] = useState<number | null>(null);
  const [proofText, setProofText] = useState("");
  const [proofImageUrl, setProofImageUrl] = useState("");

  const { data: tasks, isLoading } = trpc.tasks.list.useQuery();
  const submitMutation = trpc.tasks.submit.useMutation({
    onSuccess: () => {
      toast.success("تم إرسال المهمة بنجاح! في انتظار الموافقة");
      setSelectedTask(null);
      setProofText("");
      setProofImageUrl("");
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء إرسال المهمة");
    },
  });

  const handleSubmit = async () => {
    if (!selectedTask) return;

    if (!proofText && !proofImageUrl) {
      toast.error("يرجى إدخال دليل على إنجاز المهمة");
      return;
    }

    await submitMutation.mutateAsync({
      taskId: selectedTask,
      proofText: proofText || undefined,
      proofImageUrl: proofImageUrl || undefined,
    });
  };

  if (!user?.isSubscribed) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border">
          <div className="container py-6 flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                العودة
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-foreground">المهام المتاحة</h1>
          </div>
        </header>

        <main className="container py-12">
          <Card className="card-premium border-yellow-200 bg-yellow-50 dark:bg-yellow-950">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-yellow-800 dark:text-yellow-200">
                <AlertCircle className="w-5 h-5" />
                اشتراك مطلوب
              </CardTitle>
            </CardHeader>
            <CardContent className="text-yellow-700 dark:text-yellow-300">
              <p className="mb-6">يجب أن يكون لديك اشتراك نشط للوصول إلى المهام والبدء في كسب الأرباح</p>
              <Link href="/subscription">
                <Button className="btn-primary">عرض خطط الاشتراك</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="container py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                العودة
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-foreground">المهام المتاحة</h1>
          </div>
          <Link href="/my-submissions">
            <Button variant="outline" size="sm">عرض إرسالاتي</Button>
          </Link>
        </div>
      </header>

      <main className="container py-12">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : !tasks || tasks.length === 0 ? (
          <Card className="card-premium">
            <CardHeader>
              <CardTitle>لا توجد مهام متاحة حالياً</CardTitle>
              <CardDescription>يرجى المحاولة لاحقاً</CardDescription>
            </CardHeader>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tasks.map((task: any) => (
              <Card key={task.id} className="card-premium hover:shadow-2xl">
                <CardHeader>
                  <CardTitle className="flex items-start justify-between">
                    <span className="flex-1">{task.title}</span>
                    <span className="text-2xl font-bold text-primary ml-2">${task.reward}</span>
                  </CardTitle>
                  <CardDescription>{task.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Zap className="w-4 h-4" />
                    <span>متكررة {task.dailyLimit} مرة يومياً</span>
                  </div>

                  {task.requiresProof && (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <AlertCircle className="w-4 h-4" />
                      <span>يتطلب دليل ({task.proofType})</span>
                    </div>
                  )}

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        className="w-full btn-primary"
                        onClick={() => setSelectedTask(task.id)}
                      >
                        إرسال المهمة
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle>إرسال المهمة: {task.title}</DialogTitle>
                        <DialogDescription>
                          يرجى تقديم دليل على إنجاز المهمة
                        </DialogDescription>
                      </DialogHeader>

                      <div className="space-y-4">
                        {(task.proofType === 'text' || task.proofType === 'both') && (
                          <div>
                            <Label htmlFor="proof-text">الدليل النصي</Label>
                            <Textarea
                              id="proof-text"
                              placeholder="اكتب دليلك على إنجاز المهمة..."
                              value={proofText}
                              onChange={(e) => setProofText(e.target.value)}
                              className="mt-2"
                            />
                          </div>
                        )}

                        {(task.proofType === 'image' || task.proofType === 'both') && (
                          <div>
                            <Label htmlFor="proof-image">رابط الصورة</Label>
                            <Input
                              id="proof-image"
                              type="url"
                              placeholder="أدخل رابط الصورة..."
                              value={proofImageUrl}
                              onChange={(e) => setProofImageUrl(e.target.value)}
                              className="mt-2"
                            />
                          </div>
                        )}

                        <Button
                          className="w-full btn-primary"
                          onClick={handleSubmit}
                          disabled={submitMutation.isPending}
                        >
                          {submitMutation.isPending ? (
                            <>
                              <Loader2 className="w-4 h-4 animate-spin mr-2" />
                              جاري الإرسال...
                            </>
                          ) : (
                            <>
                              <CheckCircle className="w-4 h-4 mr-2" />
                              إرسال المهمة
                            </>
                          )}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
