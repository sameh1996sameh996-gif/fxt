import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, AlertCircle, Loader2, CheckCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Withdraw() {
  const { user } = useAuth();
  const [amount, setAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"bank_transfer" | "mobile_wallet" | "crypto">("bank_transfer");
  const [paymentDetails, setPaymentDetails] = useState<Record<string, string>>({});
  const [step, setStep] = useState<"amount" | "method" | "confirm">("amount");

  const { data: balance } = trpc.wallet.getBalance.useQuery();
  const requestMutation = trpc.withdrawals.request.useMutation({
    onSuccess: () => {
      toast.success("تم إرسال طلب السحب بنجاح! في انتظار الموافقة");
      setAmount("");
      setPaymentDetails({});
      setStep("amount");
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء إرسال طلب السحب");
    },
  });

  const balanceNum = typeof balance?.balance === 'string' ? parseFloat(balance.balance) : balance?.balance || 0;
  const amountNum = parseFloat(amount) || 0;

  const handleSubmit = async () => {
    if (!amount || amountNum <= 0) {
      toast.error("يرجى إدخال مبلغ صحيح");
      return;
    }

    if (amountNum > balanceNum) {
      toast.error("الرصيد غير كافي");
      return;
    }

    if (Object.keys(paymentDetails).length === 0) {
      toast.error("يرجى إدخال بيانات الدفع");
      return;
    }

    await requestMutation.mutateAsync({
      amount: amountNum,
      paymentMethod,
      paymentDetails,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="container py-6 flex items-center gap-4">
          <Link href="/wallet">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              العودة
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">طلب سحب الأرباح</h1>
        </div>
      </header>

      <main className="container py-12 max-w-2xl">
        {/* Balance Card */}
        <Card className="card-premium mb-8 bg-gradient-to-br from-primary/10 to-accent/10">
          <CardHeader>
            <CardTitle>رصيدك الحالي</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold text-primary">${balanceNum}</p>
            <p className="text-sm text-muted-foreground mt-2">المبلغ المتاح للسحب</p>
          </CardContent>
        </Card>

        {/* Withdrawal Form */}
        <Card className="card-premium">
          <CardHeader>
            <CardTitle>نموذج طلب السحب</CardTitle>
            <CardDescription>
              {step === "amount" && "اختر المبلغ الذي تريد سحبه"}
              {step === "method" && "اختر طريقة الدفع"}
              {step === "confirm" && "تأكد من البيانات"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 1: Amount */}
            {step === "amount" && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="amount">المبلغ المطلوب سحبه</Label>
                  <div className="relative mt-2">
                    <Input
                      id="amount"
                      type="number"
                      placeholder="أدخل المبلغ"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="pr-12"
                    />
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    الحد الأدنى: $10 | الحد الأقصى: ${balanceNum}
                  </p>
                </div>

                <Button
                  className="w-full btn-primary"
                  onClick={() => setStep("method")}
                  disabled={!amount || amountNum <= 0 || amountNum > balanceNum}
                >
                  التالي
                </Button>
              </div>
            )}

            {/* Step 2: Payment Method */}
            {step === "method" && (
              <div className="space-y-4">
                <RadioGroup value={paymentMethod} onValueChange={(value: any) => setPaymentMethod(value)}>
                  <div className="flex items-center space-x-2 p-4 border border-border rounded-lg cursor-pointer hover:bg-muted/50">
                    <RadioGroupItem value="bank_transfer" id="bank" />
                    <Label htmlFor="bank" className="flex-1 cursor-pointer">
                      <div>
                        <p className="font-semibold">تحويل بنكي</p>
                        <p className="text-xs text-muted-foreground">تحويل مباشر إلى حسابك البنكي</p>
                      </div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 p-4 border border-border rounded-lg cursor-pointer hover:bg-muted/50">
                    <RadioGroupItem value="mobile_wallet" id="mobile" />
                    <Label htmlFor="mobile" className="flex-1 cursor-pointer">
                      <div>
                        <p className="font-semibold">محفظة رقمية</p>
                        <p className="text-xs text-muted-foreground">تحويل إلى محفظتك الرقمية</p>
                      </div>
                    </Label>
                  </div>

                  <div className="flex items-center space-x-2 p-4 border border-border rounded-lg cursor-pointer hover:bg-muted/50">
                    <RadioGroupItem value="crypto" id="crypto" />
                    <Label htmlFor="crypto" className="flex-1 cursor-pointer">
                      <div>
                        <p className="font-semibold">عملات رقمية</p>
                        <p className="text-xs text-muted-foreground">تحويل إلى محفظة العملات الرقمية</p>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>

                <div className="flex gap-4">
                  <Button
                    className="flex-1 btn-outline"
                    onClick={() => setStep("amount")}
                  >
                    السابق
                  </Button>
                  <Button
                    className="flex-1 btn-primary"
                    onClick={() => setStep("confirm")}
                  >
                    التالي
                  </Button>
                </div>
              </div>
            )}

            {/* Step 3: Confirm */}
            {step === "confirm" && (
              <div className="space-y-4">
                <div className="bg-muted/50 rounded-lg p-4 space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">المبلغ:</span>
                    <span className="font-semibold">${amount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">طريقة الدفع:</span>
                    <span className="font-semibold">
                      {paymentMethod === 'bank_transfer' && 'تحويل بنكي'}
                      {paymentMethod === 'mobile_wallet' && 'محفظة رقمية'}
                      {paymentMethod === 'crypto' && 'عملات رقمية'}
                    </span>
                  </div>
                </div>

                <div className="bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4 flex gap-3">
                  <AlertCircle className="w-5 h-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-yellow-800 dark:text-yellow-200">
                    <p className="font-semibold mb-1">ملاحظة مهمة</p>
                    <p>سيتم مراجعة طلبك من قبل الفريق. قد يستغرق المعالجة من 24 إلى 48 ساعة</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    className="flex-1 btn-outline"
                    onClick={() => setStep("method")}
                  >
                    السابق
                  </Button>
                  <Button
                    className="flex-1 btn-primary"
                    onClick={handleSubmit}
                    disabled={requestMutation.isPending}
                  >
                    {requestMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        جاري الإرسال...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        تأكيد طلب السحب
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
