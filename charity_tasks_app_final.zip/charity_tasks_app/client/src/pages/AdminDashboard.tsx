import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, Plus, Check, X, Loader2, AlertCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskDescription, setNewTaskDescription] = useState("");
  const [newTaskReward, setNewTaskReward] = useState("");
  const [newTaskDailyLimit, setNewTaskDailyLimit] = useState("");

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="card-premium max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              وصول مرفوض
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-6">أنت لا تملك صلاحيات الوصول إلى لوحة التحكم</p>
            <Link href="/">
              <Button className="w-full btn-primary">العودة للرئيسية</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="container py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                العودة
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-foreground">لوحة تحكم المدير</h1>
          </div>
          <span className="text-sm text-muted-foreground">مرحباً، {user.name}</span>
        </div>
      </header>

      <main className="container py-12">
        <Tabs defaultValue="tasks" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tasks">إدارة المهام</TabsTrigger>
            <TabsTrigger value="submissions">المهام المرسلة</TabsTrigger>
            <TabsTrigger value="withdrawals">طلبات السحب</TabsTrigger>
          </TabsList>

          {/* Tasks Management Tab */}
          <TabsContent value="tasks" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-foreground">إدارة المهام</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="btn-primary">
                    <Plus className="w-4 h-4 mr-2" />
                    إضافة مهمة جديدة
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>إضافة مهمة جديدة</DialogTitle>
                    <DialogDescription>أنشئ مهمة جديدة للمستخدمين</DialogDescription>
                  </DialogHeader>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">عنوان المهمة</Label>
                      <Input
                        id="title"
                        placeholder="أدخل عنوان المهمة"
                        value={newTaskTitle}
                        onChange={(e) => setNewTaskTitle(e.target.value)}
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">الوصف</Label>
                      <Textarea
                        id="description"
                        placeholder="أدخل وصف المهمة"
                        value={newTaskDescription}
                        onChange={(e) => setNewTaskDescription(e.target.value)}
                        className="mt-2"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="reward">المكافأة ($)</Label>
                        <Input
                          id="reward"
                          type="number"
                          placeholder="0"
                          value={newTaskReward}
                          onChange={(e) => setNewTaskReward(e.target.value)}
                          className="mt-2"
                        />
                      </div>

                      <div>
                        <Label htmlFor="daily">الحد اليومي</Label>
                        <Input
                          id="daily"
                          type="number"
                          placeholder="0"
                          value={newTaskDailyLimit}
                          onChange={(e) => setNewTaskDailyLimit(e.target.value)}
                          className="mt-2"
                        />
                      </div>
                    </div>

                    <Button className="w-full btn-primary">إضافة المهمة</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="card-premium">
                <CardHeader>
                  <CardTitle>مهمة تجريبية</CardTitle>
                  <CardDescription>اكتب تقرير عن موضوع معين</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">المكافأة:</span>
                    <span className="font-semibold">$50</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">الحد اليومي:</span>
                    <span className="font-semibold">5</span>
                  </div>
                  <div className="flex gap-2">
                    <Button className="flex-1 btn-outline" size="sm">تعديل</Button>
                    <Button className="flex-1 btn-outline" size="sm" variant="destructive">حذف</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Task Submissions Tab */}
          <TabsContent value="submissions" className="space-y-6">
            <h2 className="text-2xl font-bold text-foreground">المهام المرسلة</h2>

            <Card className="card-premium">
              <CardHeader>
                <CardTitle>إرسالات قيد المراجعة</CardTitle>
                <CardDescription>لا توجد إرسالات جديدة</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-center text-muted-foreground py-8">جميع الإرسالات تمت مراجعتها</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Withdrawals Tab */}
          <TabsContent value="withdrawals" className="space-y-6">
            <h2 className="text-2xl font-bold text-foreground">طلبات السحب</h2>

            <Card className="card-premium">
              <CardHeader>
                <CardTitle>طلبات قيد المراجعة</CardTitle>
                <CardDescription>لا توجد طلبات جديدة</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-center text-muted-foreground py-8">جميع الطلبات تمت معالجتها</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
