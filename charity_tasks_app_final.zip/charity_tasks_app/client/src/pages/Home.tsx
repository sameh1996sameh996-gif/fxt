import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { 
  MessageCircle, Users, LogOut, Download, TrendingUp, 
  Zap, Gift, Wallet, ArrowUpRight, Settings, LogIn,
  Send, Share2, Crown
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading, logout, isAuthenticated } = useAuth();
  const { data: balance } = trpc.wallet.getBalance.useQuery();
  const [showSettings, setShowSettings] = useState(false);

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      window.location.href = "/";
    },
  });

  const handleLogout = async () => {
    await logoutMutation.mutateAsync();
    logout();
  };

  const quickActions = [
    { icon: MessageCircle, label: "Telegram\nGroup", color: "from-blue-500 to-blue-600", link: "#" },
    { icon: Users, label: "Invite\nFriends", color: "from-purple-500 to-purple-600", link: "/tasks" },
    { icon: Download, label: "Withdraw", color: "from-yellow-500 to-yellow-600", link: "/withdraw" },
    { icon: TrendingUp, label: "Deposit", color: "from-cyan-500 to-cyan-600", link: "/subscription" },
  ];

  const vipPlans = [
    { id: 1, name: "VIP", price: "$10.00", dailyLimit: "1 Ads", validity: "30 Days", color: "from-blue-500 to-blue-600", badge: "V1" },
    { id: 2, name: "VIP2", price: "$20.00", dailyLimit: "2 Ads", validity: "10 Days", color: "from-cyan-500 to-cyan-600", badge: "V2" },
    { id: 3, name: "VIP3", price: "$30.00", dailyLimit: "3 Ads", validity: "10 Days", color: "from-yellow-500 to-yellow-600", badge: "V3" },
    { id: 4, name: "VIP4", price: "$50.00", dailyLimit: "5 Ads", validity: "30 Days", color: "from-pink-500 to-pink-600", badge: "V4" },
    { id: 5, name: "VIP5", price: "$100.00", dailyLimit: "10 Ads", validity: "30 Days", color: "from-blue-600 to-blue-700", badge: "V5" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-500 to-pink-500 flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">WOW Tasks</h1>
              <p className="text-xs text-slate-400">Earn Daily Rewards</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAuthenticated && user ? (
              <>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowSettings(!showSettings)}
                  className="text-slate-300 hover:text-white"
                >
                  <Settings className="w-5 h-5" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={handleLogout}
                  className="text-slate-300 hover:text-red-400"
                >
                  <LogOut className="w-5 h-5" />
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white">
                  <LogIn className="w-4 h-4 mr-2" />
                  Login
                </Button>
              </a>
            )}
          </div>
        </div>
      </header>

      <main className="container py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
          </div>
        ) : isAuthenticated && user ? (
          <>
            {/* Balance Cards */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
                <CardContent className="pt-6">
                  <p className="text-xs text-slate-400 mb-2">رصيدك الحالي</p>
                  <p className="text-2xl font-bold text-white">${balance?.balance || 0}</p>
                  <p className="text-xs text-slate-500 mt-2">متاح للسحب</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
                <CardContent className="pt-6">
                  <p className="text-xs text-slate-400 mb-2">إجمالي الأرباح</p>
                  <p className="text-2xl font-bold text-cyan-400">${balance?.totalEarned || 0}</p>
                  <p className="text-xs text-slate-500 mt-2">إجمالي ما كسبته</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
                <CardContent className="pt-6">
                  <p className="text-xs text-slate-400 mb-2">تم السحب</p>
                  <p className="text-2xl font-bold text-green-400">${balance?.totalWithdrawn || 0}</p>
                  <p className="text-xs text-slate-500 mt-2">إجمالي السحب</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
                <CardContent className="pt-6">
                  <p className="text-xs text-slate-400 mb-2">المهام المكتملة</p>
                  <p className="text-2xl font-bold text-yellow-400">0</p>
                  <p className="text-xs text-slate-500 mt-2">هذا الشهر</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <div className="mb-8">
              <h2 className="text-lg font-bold text-white mb-4">الإجراءات السريعة</h2>
              <div className="grid grid-cols-4 gap-3">
                {quickActions.map((action, idx) => {
                  const Icon = action.icon;
                  return (
                    <Link key={idx} href={action.link}>
                      <button className="w-full">
                        <div className={`bg-gradient-to-br ${action.color} rounded-lg p-4 flex flex-col items-center justify-center gap-2 hover:shadow-lg hover:shadow-current transition-all`}>
                          <Icon className="w-6 h-6 text-white" />
                          <span className="text-xs font-semibold text-white text-center">{action.label}</span>
                        </div>
                      </button>
                    </Link>
                  );
                })}
              </div>
            </div>

            {/* VIP Plans */}
            <div className="mb-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Crown className="w-5 h-5 text-yellow-400" />
                  خطط VIP
                </h2>
                <Link href="/subscription">
                  <Button variant="ghost" size="sm" className="text-orange-400 hover:text-orange-300">
                    عرض الكل →
                  </Button>
                </Link>
              </div>

              <div className="space-y-3">
                {vipPlans.map((plan) => (
                  <Link key={plan.id} href="/subscription">
                    <div className={`bg-gradient-to-r ${plan.color} rounded-lg p-4 flex items-center justify-between hover:shadow-lg transition-all cursor-pointer`}>
                      <div className="flex-1">
                        <p className="font-bold text-white">{plan.name}</p>
                        <p className="text-sm text-white/80">{plan.price} • {plan.dailyLimit} | Validity: {plan.validity}</p>
                      </div>
                      <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center">
                        <span className="font-bold text-white text-lg">{plan.badge}</span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Settings Panel */}
            {showSettings && (
              <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 mb-8">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Settings className="w-5 h-5" />
                    الإعدادات
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Link href="/profile">
                    <Button className="w-full bg-slate-700 hover:bg-slate-600 text-white">
                      الملف الشخصي
                    </Button>
                  </Link>
                  <Link href="/wallet">
                    <Button className="w-full bg-slate-700 hover:bg-slate-600 text-white">
                      المحفظة
                    </Button>
                  </Link>
                  <Link href="/my-submissions">
                    <Button className="w-full bg-slate-700 hover:bg-slate-600 text-white">
                      إرسالاتي
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </>
        ) : (
          <div className="text-center py-20">
            <div className="mb-6">
              <Zap className="w-16 h-16 text-orange-500 mx-auto" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">مرحباً بك في WOW Tasks</h2>
            <p className="text-slate-400 mb-6">ابدأ كسب الأموال اليوم من خلال إكمال المهام البسيطة</p>
            <a href={getLoginUrl()}>
              <Button className="bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white px-8 py-6 text-lg">
                <LogIn className="w-5 h-5 mr-2" />
                ابدأ الآن
              </Button>
            </a>
          </div>
        )}
      </main>
    </div>
  );
}
