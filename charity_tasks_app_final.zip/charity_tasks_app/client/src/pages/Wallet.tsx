import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, Wallet, TrendingUp, Send, ArrowUpRight, ArrowDownLeft } from "lucide-react";
import { Loader2 } from "lucide-react";

export default function WalletPage() {
  const { user } = useAuth();
  const { data: balance, isLoading: balanceLoading } = trpc.wallet.getBalance.useQuery();
  const { data: transactions, isLoading: transactionsLoading } = trpc.wallet.getTransactions.useQuery();

  const getTransactionIcon = (type: string) => {
    if (type === 'task_reward') return <ArrowDownLeft className="w-4 h-4 text-green-600" />;
    if (type === 'withdrawal') return <ArrowUpRight className="w-4 h-4 text-red-600" />;
    return <ArrowDownLeft className="w-4 h-4 text-blue-600" />;
  };

  const getTransactionColor = (type: string) => {
    if (type === 'task_reward') return 'text-green-600';
    if (type === 'withdrawal') return 'text-red-600';
    return 'text-blue-600';
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="container py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                العودة
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-foreground">محفظتي الرقمية</h1>
          </div>
          <Link href="/withdraw">
            <Button className="btn-primary">
              <Send className="w-4 h-4 mr-2" />
              طلب سحب
            </Button>
          </Link>
        </div>
      </header>

      <main className="container py-12">
        {balanceLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Balance Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <Card className="card-premium bg-gradient-to-br from-primary/10 to-accent/10">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-primary" />
                    الرصيد الحالي
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold text-primary">${balance?.balance || 0}</p>
                  <p className="text-sm text-muted-foreground mt-2">رصيدك المتاح للسحب</p>
                </CardContent>
              </Card>

              <Card className="card-premium bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    إجمالي الأرباح
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold text-green-600">${balance?.totalEarned || 0}</p>
                  <p className="text-sm text-muted-foreground mt-2">إجمالي ما كسبته</p>
                </CardContent>
              </Card>

              <Card className="card-premium bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Send className="w-5 h-5 text-blue-600" />
                    إجمالي السحب
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-4xl font-bold text-blue-600">${balance?.totalWithdrawn || 0}</p>
                  <p className="text-sm text-muted-foreground mt-2">إجمالي ما سحبته</p>
                </CardContent>
              </Card>
            </div>

            {/* Transactions */}
            <Card className="card-premium">
              <CardHeader>
                <CardTitle>سجل المعاملات</CardTitle>
                <CardDescription>جميع معاملاتك المالية</CardDescription>
              </CardHeader>
              <CardContent>
                {transactionsLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : !transactions || transactions.length === 0 ? (
                  <p className="text-center text-muted-foreground py-8">لا توجد معاملات حتى الآن</p>
                ) : (
                  <div className="space-y-4">
                    {transactions.map((transaction: any) => (
                      <div
                        key={transaction.id}
                        className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                            {getTransactionIcon(transaction.type)}
                          </div>
                          <div>
                            <p className="font-semibold text-foreground">{transaction.description}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(transaction.createdAt).toLocaleDateString('ar-SA')}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`text-lg font-bold ${getTransactionColor(transaction.type)}`}>
                            {transaction.type === 'withdrawal' ? '-' : '+'}
                            ${transaction.amount}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            الرصيد: ${transaction.balanceAfter}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </main>
    </div>
  );
}
