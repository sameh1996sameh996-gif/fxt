import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { ArrowLeft, AlertCircle, Loader2, Save, Palette, Type, Settings } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface SiteSettings {
  siteName: string;
  siteDescription: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  headerText: string;
  headerSubtext: string;
  minWithdrawal: string;
  maxWithdrawal: string;
  telegramLink: string;
  supportEmail: string;
}

export default function SettingsPanel() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [settings, setSettings] = useState<SiteSettings>({
    siteName: "WOW Tasks",
    siteDescription: "Earn Daily Rewards",
    primaryColor: "#f97316",
    secondaryColor: "#ec4899",
    accentColor: "#06b6d4",
    backgroundColor: "#0f172a",
    headerText: "مرحباً بك في WOW Tasks",
    headerSubtext: "ابدأ كسب الأموال اليوم من خلال إكمال المهام البسيطة",
    minWithdrawal: "10",
    maxWithdrawal: "10000",
    telegramLink: "https://t.me/yourgroupname",
    supportEmail: "support@example.com",
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 flex items-center justify-center">
        <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-400">
              <AlertCircle className="w-5 h-5" />
              وصول مرفوض
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-300 mb-6">أنت لا تملك صلاحيات الوصول إلى لوحة التحكم</p>
            <Link href="/">
              <Button className="w-full bg-gradient-to-r from-orange-500 to-pink-500">العودة للرئيسية</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleInputChange = (field: keyof SiteSettings, value: string) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      // محاكاة حفظ الإعدادات
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success("تم حفظ الإعدادات بنجاح!");
      console.log("Settings saved:", settings);
    } catch (error) {
      toast.error("حدث خطأ أثناء حفظ الإعدادات");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
        <div className="container py-6 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-slate-300">
              <ArrowLeft className="w-4 h-4 mr-2" />
              العودة
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-white">لوحة تحكم التخصيص</h1>
        </div>
      </header>

      <main className="container py-12 max-w-4xl">
        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800">
            <TabsTrigger value="general" className="text-slate-300">عام</TabsTrigger>
            <TabsTrigger value="design" className="text-slate-300">التصميم</TabsTrigger>
            <TabsTrigger value="advanced" className="text-slate-300">متقدم</TabsTrigger>
          </TabsList>

          {/* General Tab */}
          <TabsContent value="general" className="space-y-6">
            <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Settings className="w-5 h-5" />
                  الإعدادات العامة
                </CardTitle>
                <CardDescription className="text-slate-400">تخصيص معلومات الموقع الأساسية</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="text-slate-300">اسم الموقع</Label>
                  <Input
                    value={settings.siteName}
                    onChange={(e) => handleInputChange('siteName', e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                    placeholder="اسم الموقع"
                  />
                </div>

                <div>
                  <Label className="text-slate-300">وصف الموقع</Label>
                  <Input
                    value={settings.siteDescription}
                    onChange={(e) => handleInputChange('siteDescription', e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                    placeholder="وصف قصير للموقع"
                  />
                </div>

                <div>
                  <Label className="text-slate-300">رابط مجموعة Telegram</Label>
                  <Input
                    value={settings.telegramLink}
                    onChange={(e) => handleInputChange('telegramLink', e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                    placeholder="https://t.me/yourgroup"
                  />
                </div>

                <div>
                  <Label className="text-slate-300">بريد الدعم</Label>
                  <Input
                    value={settings.supportEmail}
                    onChange={(e) => handleInputChange('supportEmail', e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                    placeholder="support@example.com"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Design Tab */}
          <TabsContent value="design" className="space-y-6">
            <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Palette className="w-5 h-5" />
                  تخصيص الألوان
                </CardTitle>
                <CardDescription className="text-slate-400">اختر الألوان المفضلة لموقعك</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <Label className="text-slate-300">اللون الأساسي</Label>
                    <div className="mt-2 flex gap-3">
                      <input
                        type="color"
                        value={settings.primaryColor}
                        onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                        className="w-12 h-12 rounded cursor-pointer"
                      />
                      <Input
                        value={settings.primaryColor}
                        onChange={(e) => handleInputChange('primaryColor', e.target.value)}
                        className="flex-1 bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-slate-300">اللون الثانوي</Label>
                    <div className="mt-2 flex gap-3">
                      <input
                        type="color"
                        value={settings.secondaryColor}
                        onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                        className="w-12 h-12 rounded cursor-pointer"
                      />
                      <Input
                        value={settings.secondaryColor}
                        onChange={(e) => handleInputChange('secondaryColor', e.target.value)}
                        className="flex-1 bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-slate-300">اللون الثالث</Label>
                    <div className="mt-2 flex gap-3">
                      <input
                        type="color"
                        value={settings.accentColor}
                        onChange={(e) => handleInputChange('accentColor', e.target.value)}
                        className="w-12 h-12 rounded cursor-pointer"
                      />
                      <Input
                        value={settings.accentColor}
                        onChange={(e) => handleInputChange('accentColor', e.target.value)}
                        className="flex-1 bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-slate-300">لون الخلفية</Label>
                    <div className="mt-2 flex gap-3">
                      <input
                        type="color"
                        value={settings.backgroundColor}
                        onChange={(e) => handleInputChange('backgroundColor', e.target.value)}
                        className="w-12 h-12 rounded cursor-pointer"
                      />
                      <Input
                        value={settings.backgroundColor}
                        onChange={(e) => handleInputChange('backgroundColor', e.target.value)}
                        className="flex-1 bg-slate-700 border-slate-600 text-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Preview */}
                <div className="mt-8 p-6 rounded-lg" style={{ backgroundColor: settings.backgroundColor }}>
                  <h3 className="text-2xl font-bold mb-2" style={{ color: settings.primaryColor }}>
                    معاينة التصميم
                  </h3>
                  <p className="mb-4" style={{ color: settings.secondaryColor }}>
                    هذا مثال على كيفية ظهور الألوان على موقعك
                  </p>
                  <button 
                    className="px-6 py-2 rounded-lg font-semibold text-white"
                    style={{ backgroundColor: settings.accentColor }}
                  >
                    زر تجريبي
                  </button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Advanced Tab */}
          <TabsContent value="advanced" className="space-y-6">
            <Card className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Type className="w-5 h-5" />
                  النصوص والرسائل
                </CardTitle>
                <CardDescription className="text-slate-400">تخصيص النصوص المعروضة على الموقع</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="text-slate-300">نص الرأس الرئيسي</Label>
                  <Input
                    value={settings.headerText}
                    onChange={(e) => handleInputChange('headerText', e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                    placeholder="النص الرئيسي"
                  />
                </div>

                <div>
                  <Label className="text-slate-300">النص الفرعي</Label>
                  <Textarea
                    value={settings.headerSubtext}
                    onChange={(e) => handleInputChange('headerSubtext', e.target.value)}
                    className="mt-2 bg-slate-700 border-slate-600 text-white placeholder-slate-500"
                    placeholder="النص الفرعي"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-slate-300">الحد الأدنى للسحب ($)</Label>
                    <Input
                      type="number"
                      value={settings.minWithdrawal}
                      onChange={(e) => handleInputChange('minWithdrawal', e.target.value)}
                      className="mt-2 bg-slate-700 border-slate-600 text-white"
                    />
                  </div>

                  <div>
                    <Label className="text-slate-300">الحد الأقصى للسحب ($)</Label>
                    <Input
                      type="number"
                      value={settings.maxWithdrawal}
                      onChange={(e) => handleInputChange('maxWithdrawal', e.target.value)}
                      className="mt-2 bg-slate-700 border-slate-600 text-white"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="mt-8 flex gap-4">
          <Button
            onClick={handleSave}
            disabled={isLoading}
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-8"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                جاري الحفظ...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                حفظ الإعدادات
              </>
            )}
          </Button>
          <Link href="/">
            <Button variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-800">
              إلغاء
            </Button>
          </Link>
        </div>
      </main>
    </div>
  );
}
