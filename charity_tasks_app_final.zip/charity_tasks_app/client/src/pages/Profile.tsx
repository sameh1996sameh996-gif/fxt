import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, Loader2, LogOut, Mail, User } from "lucide-react";
import { toast } from "sonner";

export default function Profile() {
  const { user, logout } = useAuth();
  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      logout();
      toast.success("تم تسجيل الخروج بنجاح");
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="container py-6 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              العودة
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">الملف الشخصي</h1>
        </div>
      </header>

      <main className="container py-12 max-w-2xl">
        {/* Profile Information */}
        <Card className="card-premium mb-8">
          <CardHeader>
            <CardTitle>معلومات الحساب</CardTitle>
            <CardDescription>بيانات حسابك الشخصية</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label className="text-muted-foreground">الاسم</Label>
              <div className="flex items-center gap-3 mt-2 p-3 bg-muted/50 rounded-lg">
                <User className="w-5 h-5 text-muted-foreground" />
                <span className="font-semibold text-foreground">{user?.name || 'غير محدد'}</span>
              </div>
            </div>

            <div>
              <Label className="text-muted-foreground">البريد الإلكتروني</Label>
              <div className="flex items-center gap-3 mt-2 p-3 bg-muted/50 rounded-lg">
                <Mail className="w-5 h-5 text-muted-foreground" />
                <span className="font-semibold text-foreground">{user?.email || 'غير محدد'}</span>
              </div>
            </div>

            <div>
              <Label className="text-muted-foreground">نوع الحساب</Label>
              <div className="mt-2 p-3 bg-muted/50 rounded-lg">
                <span className="font-semibold text-foreground">
                  {user?.role === 'admin' ? 'مدير' : 'مستخدم عادي'}
                </span>
              </div>
            </div>

            <div>
              <Label className="text-muted-foreground">تاريخ الانضمام</Label>
              <div className="mt-2 p-3 bg-muted/50 rounded-lg">
                <span className="font-semibold text-foreground">
                  {user?.createdAt ? new Date(user.createdAt).toLocaleDateString('ar-SA') : 'غير محدد'}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Links */}
        <Card className="card-premium mb-8">
          <CardHeader>
            <CardTitle>الروابط السريعة</CardTitle>
            <CardDescription>الوصول السريع للمميزات الرئيسية</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Link href="/tasks">
              <Button className="w-full btn-outline justify-start">
                عرض المهام المتاحة
              </Button>
            </Link>
            <Link href="/wallet">
              <Button className="w-full btn-outline justify-start">
                محفظتي الرقمية
              </Button>
            </Link>
            <Link href="/my-submissions">
              <Button className="w-full btn-outline justify-start">
                إرسالاتي
              </Button>
            </Link>
            <Link href="/withdraw">
              <Button className="w-full btn-outline justify-start">
                طلب سحب الأرباح
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Account Actions */}
        <Card className="card-premium border-red-200 dark:border-red-800">
          <CardHeader>
            <CardTitle className="text-red-600 dark:text-red-400">إجراءات الحساب</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              className="w-full bg-red-600 hover:bg-red-700 text-white"
              onClick={handleLogout}
              disabled={logoutMutation.isPending}
            >
              {logoutMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  جاري تسجيل الخروج...
                </>
              ) : (
                <>
                  <LogOut className="w-4 h-4 mr-2" />
                  تسجيل الخروج
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
