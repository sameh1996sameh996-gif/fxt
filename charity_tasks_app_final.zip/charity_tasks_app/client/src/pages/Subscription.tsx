import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";

export default function Subscription() {
  const { user } = useAuth();
  const { data: plans, isLoading } = trpc.subscription.getPlans.useQuery();
  const { data: currentSubscription } = trpc.subscription.getCurrentSubscription.useQuery();
  const purchaseMutation = trpc.subscription.purchase.useMutation({
    onSuccess: () => {
      toast.success("تم شراء الاشتراك بنجاح!");
    },
    onError: (error) => {
      toast.error(error.message || "حدث خطأ أثناء شراء الاشتراك");
    },
  });

  const handlePurchase = async (planId: number) => {
    await purchaseMutation.mutateAsync({ planId });
  };

  if (user?.isSubscribed && currentSubscription) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border">
          <div className="container py-6 flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                العودة
              </Button>
            </Link>
            <h1 className="text-2xl font-bold text-foreground">الاشتراك</h1>
          </div>
        </header>

        <main className="container py-12">
          <Card className="card-premium border-green-200 bg-green-50 dark:bg-green-950">
            <CardHeader>
              <CardTitle className="text-green-800 dark:text-green-200">اشتراك نشط</CardTitle>
            </CardHeader>
            <CardContent className="text-green-700 dark:text-green-300">
              <p className="mb-4">لديك اشتراك نشط حالياً</p>
              <p className="text-sm">
                ينتهي في: {new Date(currentSubscription.expiresAt).toLocaleDateString('ar-SA')}
              </p>
              <Link href="/tasks" className="mt-6 inline-block">
                <Button className="btn-primary">ابدأ بإنجاز المهام</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="container py-6 flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              العودة
            </Button>
          </Link>
          <h1 className="text-2xl font-bold text-foreground">خطط الاشتراك</h1>
        </div>
      </header>

      <main className="container py-12">
        <div className="mb-12">
          <h2 className="text-3xl font-bold mb-4 text-foreground">اختر خطتك المفضلة</h2>
          <p className="text-lg text-muted-foreground">ابدأ بالاشتراك واكسب الأرباح الآن</p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : !plans || plans.length === 0 ? (
          <Card className="card-premium">
            <CardHeader>
              <CardTitle>لا توجد خطط متاحة حالياً</CardTitle>
            </CardHeader>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {plans.map((plan: any, index: number) => (
              <Card
                key={plan.id}
                className={`card-premium flex flex-col ${
                  index === 1 ? 'ring-2 ring-primary lg:scale-105' : ''
                }`}
              >
                {index === 1 && (
                  <div className="bg-primary text-primary-foreground py-2 px-4 text-center text-sm font-semibold">
                    الخطة الموصى بها
                  </div>
                )}
                <CardHeader>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <div className="mb-6">
                    <p className="text-4xl font-bold text-primary mb-2">${plan.price}</p>
                    <p className="text-sm text-muted-foreground">
                      لمدة {plan.durationDays} يوم
                    </p>
                  </div>

                  <div className="space-y-3 mb-8 flex-1">
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">وصول كامل للمهام</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">سحب الأرباح بدون حد أدنى</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">دعم فني متاح 24/7</span>
                    </div>
                    <div className="flex items-start gap-3">
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">إشعارات فورية للمهام</span>
                    </div>
                  </div>

                  <Button
                    className={`w-full ${
                      index === 1 ? 'btn-primary' : 'btn-outline'
                    }`}
                    onClick={() => handlePurchase(plan.id)}
                    disabled={purchaseMutation.isPending}
                  >
                    {purchaseMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin mr-2" />
                        جاري المعالجة...
                      </>
                    ) : (
                      'اشترك الآن'
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* FAQ Section */}
        <div className="mt-16 bg-card rounded-xl border border-border p-8">
          <h3 className="text-2xl font-bold mb-8 text-foreground">الأسئلة الشائعة</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-semibold mb-2 text-foreground">هل يمكنني إلغاء الاشتراك؟</h4>
              <p className="text-sm text-muted-foreground">
                نعم، يمكنك إلغاء الاشتراك في أي وقت. لن يتم فرض أي رسوم إضافية
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-foreground">هل هناك فترة تجريبية؟</h4>
              <p className="text-sm text-muted-foreground">
                نعم، نقدم فترة تجريبية مجانية لمدة 3 أيام
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-foreground">كيف يتم الدفع؟</h4>
              <p className="text-sm text-muted-foreground">
                نقبل جميع طرق الدفع الرئيسية بما فيها بطاقات الائتمان والمحافظ الرقمية
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2 text-foreground">هل هناك خصومات جماعية؟</h4>
              <p className="text-sm text-muted-foreground">
                نعم، اتصل بنا للاستفسار عن خصومات الاشتراكات الجماعية
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
