import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getDb, getUserById, getActiveTasks, getTaskSubmissionsByUserId, getTransactionsByUserId, getWithdrawalsByUserId, getActiveSubscriptionPlans, getUserSubscription, getNotificationsByUserId, getUnreadNotificationsByUserId, getPendingTaskSubmissions, getPendingWithdrawals, getTaskSubmissionById, getWithdrawalById, getTaskById } from "./db";
import { taskSubmissions, transactions, withdrawals, subscriptionPurchases, notifications, tasks, users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Admin-only procedure
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Only admins can access this' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // User wallet and profile
  wallet: router({
    getBalance: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserById(ctx.user.id);
      const balance = typeof user?.balance === 'string' ? parseFloat(user.balance) : user?.balance || 0;
      const totalEarned = typeof user?.totalEarned === 'string' ? parseFloat(user.totalEarned) : user?.totalEarned || 0;
      const totalWithdrawn = typeof user?.totalWithdrawn === 'string' ? parseFloat(user.totalWithdrawn) : user?.totalWithdrawn || 0;
      return { balance, totalEarned, totalWithdrawn };
    }),

    getTransactions: protectedProcedure.query(async ({ ctx }) => {
      return await getTransactionsByUserId(ctx.user.id);
    }),
  }),

  // Subscription management
  subscription: router({
    getPlans: publicProcedure.query(async () => {
      return await getActiveSubscriptionPlans();
    }),

    getCurrentSubscription: protectedProcedure.query(async ({ ctx }) => {
      return await getUserSubscription(ctx.user.id);
    }),

    purchase: protectedProcedure
      .input(z.object({ planId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const plans = await getActiveSubscriptionPlans();
        const selectedPlan = plans.find(p => p.id === input.planId);
        if (!selectedPlan) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Plan not found' });
        }

        const expiresAt = new Date();
        expiresAt.setDate(expiresAt.getDate() + selectedPlan.durationDays);

        await db.insert(subscriptionPurchases).values({
          userId: ctx.user.id,
          planId: input.planId,
          expiresAt,
        });

        await db.update(users).set({
          isSubscribed: true,
          subscriptionExpiresAt: expiresAt,
        }).where(eq(users.id, ctx.user.id));

        return { success: true, expiresAt } as const;
      }),
  }),

  // Tasks management
  tasks: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const user = await getUserById(ctx.user.id);
      if (!user?.isSubscribed) {
        throw new TRPCError({ code: 'FORBIDDEN', message: 'You must have an active subscription' });
      }
      return await getActiveTasks();
    }),

    submit: protectedProcedure
      .input(z.object({
        taskId: z.number(),
        proofText: z.string().optional(),
        proofImageUrl: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const user = await getUserById(ctx.user.id);
        if (!user?.isSubscribed) {
          throw new TRPCError({ code: 'FORBIDDEN', message: 'You must have an active subscription' });
        }

        const task = await getTaskById(input.taskId);
        if (!task) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Task not found' });
        }

        const submission = await db.insert(taskSubmissions).values({
          userId: ctx.user.id,
          taskId: input.taskId,
          proofText: input.proofText,
          proofImageUrl: input.proofImageUrl,
        });

        const submissionResult = submission as any;
        const submissionId = Array.isArray(submissionResult) ? submissionResult[0] : submissionResult.insertId;

        await db.insert(notifications).values({
          userId: 1,
          title: 'New Task Submission',
          message: `${user.name} submitted task: ${task.title}`,
          type: 'system',
          taskSubmissionId: submissionId,
        });

        return { success: true, submissionId } as const;
      }),

    getUserSubmissions: protectedProcedure.query(async ({ ctx }) => {
      return await getTaskSubmissionsByUserId(ctx.user.id);
    }),
  }),

  // Withdrawals
  withdrawals: router({
    request: protectedProcedure
      .input(z.object({
        amount: z.number().positive(),
        paymentMethod: z.enum(['bank_transfer', 'mobile_wallet', 'crypto']),
        paymentDetails: z.record(z.string(), z.any()),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const user = await getUserById(ctx.user.id);
        const userBalanceNum = typeof user?.balance === 'string' ? parseFloat(user.balance) : user?.balance || 0;
        if (!user || userBalanceNum < input.amount) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'Insufficient balance' });
        }

        const withdrawal = await db.insert(withdrawals).values({
          userId: ctx.user.id,
          amount: input.amount.toString(),
          paymentMethod: input.paymentMethod,
          paymentDetails: JSON.stringify(input.paymentDetails),
        });

        const withdrawalResult = withdrawal as any;
        const withdrawalId = Array.isArray(withdrawalResult) ? withdrawalResult[0] : withdrawalResult.insertId;

        await db.insert(notifications).values({
          userId: 1,
          title: 'New Withdrawal Request',
          message: `${user.name} requested withdrawal of ${input.amount}`,
          type: 'system',
          withdrawalId: withdrawalId,
        });

        return { success: true, withdrawalId } as const;
      }),

    getUserWithdrawals: protectedProcedure.query(async ({ ctx }) => {
      return await getWithdrawalsByUserId(ctx.user.id);
    }),
  }),

  // Notifications
  notifications: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await getNotificationsByUserId(ctx.user.id);
    }),

    getUnread: protectedProcedure.query(async ({ ctx }) => {
      return await getUnreadNotificationsByUserId(ctx.user.id);
    }),

    markAsRead: protectedProcedure
      .input(z.object({ notificationId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        await db.update(notifications).set({
          isRead: true,
        }).where(eq(notifications.id, input.notificationId));

        return { success: true } as const;
      }),
  }),

  // Admin routes
  admin: router({
    // Task management
    createTask: adminProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        reward: z.number().positive(),
        dailyLimit: z.number().positive(),
        requiresProof: z.boolean(),
        proofType: z.enum(['text', 'image', 'both']).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const task = await db.insert(tasks).values({
          title: input.title,
          description: input.description,
          reward: input.reward.toString(),
          dailyLimit: input.dailyLimit,
          requiresProof: input.requiresProof,
          proofType: input.proofType,
          createdBy: ctx.user.id,
        });

        const taskResult = task as any;
        const taskId = Array.isArray(taskResult) ? taskResult[0] : taskResult.insertId;

        return { success: true, taskId } as const;
      }),

    updateTask: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        reward: z.number().optional(),
        dailyLimit: z.number().optional(),
        isActive: z.boolean().optional(),
        requiresProof: z.boolean().optional(),
        proofType: z.enum(['text', 'image', 'both']).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const { id, reward, ...updateData } = input;
        const updateSet: any = updateData;
        if (reward !== undefined) {
          updateSet.reward = reward.toString();
        }
        await db.update(tasks).set(updateSet).where(eq(tasks.id, id));

        return { success: true } as const;
      }),

    deleteTask: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        await db.update(tasks).set({ isActive: false }).where(eq(tasks.id, input.id));

        return { success: true } as const;
      }),

    // Task submissions review
    getPendingSubmissions: adminProcedure.query(async () => {
      return await getPendingTaskSubmissions();
    }),

    approveSubmission: adminProcedure
      .input(z.object({ submissionId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const submission = await getTaskSubmissionById(input.submissionId);
        if (!submission) throw new TRPCError({ code: 'NOT_FOUND' });

        const task = await getTaskById(submission.taskId);
        if (!task) throw new TRPCError({ code: 'NOT_FOUND' });

        const user = await getUserById(submission.userId);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });

        await db.update(taskSubmissions).set({
          status: 'approved',
          reviewedAt: new Date(),
          reviewedBy: ctx.user.id,
        }).where(eq(taskSubmissions.id, input.submissionId));

        const rewardNum = typeof task.reward === 'string' ? parseFloat(task.reward) : task.reward;
        const userBalanceNum = typeof user.balance === 'string' ? parseFloat(user.balance) : user.balance || 0;
        const userEarnedNum = typeof user.totalEarned === 'string' ? parseFloat(user.totalEarned) : user.totalEarned || 0;
        
        const newBalance = userBalanceNum + rewardNum;
        const newEarned = userEarnedNum + rewardNum;

        await db.update(users).set({
          balance: newBalance.toString(),
          totalEarned: newEarned.toString(),
        }).where(eq(users.id, submission.userId));

        await db.insert(transactions).values({
          userId: submission.userId,
          type: 'task_reward' as const,
          amount: rewardNum.toString(),
          description: `Reward for task: ${task.title}`,
          taskSubmissionId: input.submissionId,
          balanceBefore: userBalanceNum.toString(),
          balanceAfter: newBalance.toString(),
        });

        await db.insert(notifications).values({
          userId: submission.userId,
          title: 'Task Approved',
          message: `Your submission for "${task.title}" has been approved! You earned ${task.reward}`,
          type: 'task_approved',
          taskSubmissionId: input.submissionId,
        });

        return { success: true } as const;
      }),

    rejectSubmission: adminProcedure
      .input(z.object({ submissionId: z.number(), reason: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const submission = await getTaskSubmissionById(input.submissionId);
        if (!submission) throw new TRPCError({ code: 'NOT_FOUND' });

        const task = await getTaskById(submission.taskId);
        if (!task) throw new TRPCError({ code: 'NOT_FOUND' });

        await db.update(taskSubmissions).set({
          status: 'rejected',
          rejectionReason: input.reason,
          reviewedAt: new Date(),
          reviewedBy: ctx.user.id,
        }).where(eq(taskSubmissions.id, input.submissionId));

        await db.insert(notifications).values({
          userId: submission.userId,
          title: 'Task Rejected',
          message: `Your submission for "${task.title}" was rejected. Reason: ${input.reason}`,
          type: 'task_rejected',
          taskSubmissionId: input.submissionId,
        });

        return { success: true } as const;
      }),

    // Withdrawals review
    getPendingWithdrawals: adminProcedure.query(async () => {
      return await getPendingWithdrawals();
    }),

    approveWithdrawal: adminProcedure
      .input(z.object({ withdrawalId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const withdrawal = await getWithdrawalById(input.withdrawalId);
        if (!withdrawal) throw new TRPCError({ code: 'NOT_FOUND' });

        const user = await getUserById(withdrawal.userId);
        if (!user) throw new TRPCError({ code: 'NOT_FOUND' });

        await db.update(withdrawals).set({
          status: 'completed',
          reviewedAt: new Date(),
          reviewedBy: ctx.user.id,
          completedAt: new Date(),
        }).where(eq(withdrawals.id, input.withdrawalId));

        const withdrawalNum = typeof withdrawal.amount === 'string' ? parseFloat(withdrawal.amount) : withdrawal.amount;
        const userBalanceNum = typeof user.balance === 'string' ? parseFloat(user.balance) : user.balance || 0;
        const userWithdrawnNum = typeof user.totalWithdrawn === 'string' ? parseFloat(user.totalWithdrawn) : user.totalWithdrawn || 0;
        
        const newBalance = userBalanceNum - withdrawalNum;
        const newWithdrawn = userWithdrawnNum + withdrawalNum;

        await db.update(users).set({
          balance: newBalance.toString(),
          totalWithdrawn: newWithdrawn.toString(),
        }).where(eq(users.id, withdrawal.userId));

        await db.insert(transactions).values({
          userId: withdrawal.userId,
          type: 'withdrawal' as const,
          amount: withdrawalNum.toString(),
          description: `Withdrawal via ${withdrawal.paymentMethod}`,
          withdrawalId: input.withdrawalId,
          balanceBefore: userBalanceNum.toString(),
          balanceAfter: newBalance.toString(),
        });

        await db.insert(notifications).values({
          userId: withdrawal.userId,
          title: 'Withdrawal Approved',
          message: `Your withdrawal request of ${withdrawal.amount} has been approved and processed`,
          type: 'withdrawal_approved',
          withdrawalId: input.withdrawalId,
        });

        return { success: true } as const;
      }),

    rejectWithdrawal: adminProcedure
      .input(z.object({ withdrawalId: z.number(), reason: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: 'INTERNAL_SERVER_ERROR' });

        const withdrawal = await getWithdrawalById(input.withdrawalId);
        if (!withdrawal) throw new TRPCError({ code: 'NOT_FOUND' });

        await db.update(withdrawals).set({
          status: 'rejected',
          rejectionReason: input.reason,
          reviewedAt: new Date(),
          reviewedBy: ctx.user.id,
        }).where(eq(withdrawals.id, input.withdrawalId));

        await db.insert(notifications).values({
          userId: withdrawal.userId,
          title: 'Withdrawal Rejected',
          message: `Your withdrawal request was rejected. Reason: ${input.reason}`,
          type: 'withdrawal_rejected',
          withdrawalId: input.withdrawalId,
        });

        return { success: true } as const;
      }),
  }),
});

export type AppRouter = typeof appRouter;
