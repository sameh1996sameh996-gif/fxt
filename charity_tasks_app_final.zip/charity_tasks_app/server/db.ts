import { eq, and, desc, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, tasks, taskSubmissions, transactions, withdrawals, subscriptionPlans, subscriptionPurchases, notifications } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Tasks queries
export async function getActiveTasks() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(tasks).where(eq(tasks.isActive, true));
}

export async function getTaskById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(tasks).where(eq(tasks.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Task submissions queries
export async function getTaskSubmissionsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(taskSubmissions)
    .where(eq(taskSubmissions.userId, userId))
    .orderBy(desc(taskSubmissions.submittedAt));
}

export async function getPendingTaskSubmissions() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(taskSubmissions)
    .where(eq(taskSubmissions.status, 'pending'))
    .orderBy(desc(taskSubmissions.submittedAt));
}

export async function getTaskSubmissionById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(taskSubmissions)
    .where(eq(taskSubmissions.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Transactions queries
export async function getTransactionsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy(desc(transactions.createdAt));
}

// Withdrawals queries
export async function getWithdrawalsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(withdrawals)
    .where(eq(withdrawals.userId, userId))
    .orderBy(desc(withdrawals.requestedAt));
}

export async function getPendingWithdrawals() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(withdrawals)
    .where(eq(withdrawals.status, 'pending'))
    .orderBy(desc(withdrawals.requestedAt));
}

export async function getWithdrawalById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(withdrawals)
    .where(eq(withdrawals.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Subscription plans queries
export async function getActiveSubscriptionPlans() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(subscriptionPlans)
    .where(eq(subscriptionPlans.isActive, true));
}

export async function getSubscriptionPlanById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(subscriptionPlans)
    .where(eq(subscriptionPlans.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Subscription purchases queries
export async function getUserSubscription(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(subscriptionPurchases)
    .where(eq(subscriptionPurchases.userId, userId))
    .orderBy(desc(subscriptionPurchases.purchasedAt))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Notifications queries
export async function getNotificationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function getUnreadNotificationsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(notifications)
    .where(and(
      eq(notifications.userId, userId),
      eq(notifications.isRead, false)
    ))
    .orderBy(desc(notifications.createdAt));
}
